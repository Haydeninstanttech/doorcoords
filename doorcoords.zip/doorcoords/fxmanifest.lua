fx_version 'cerulean'
game 'gta5'

author 'CloudSparc Development'
description 'Get coordinates of the nearest door using raycast'
version '1.0.0'

client_script 'client.lua'