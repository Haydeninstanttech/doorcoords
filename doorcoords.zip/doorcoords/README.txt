--CloudSparc Development-- 

Chat Command: /getdoorcoords 

Very simple but helpful script 
Enjoy.  